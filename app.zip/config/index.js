const dotenv = require('dotenv');
dotenv.config()
module.exports = {
    APP_PORT,
    DB_LINK
} = process.env;